# app.py - Fixed & Improved Version
import os
import gradio as gr
from pathlib import Path
import shutil
import zipfile
import subprocess
import re
from dotenv import load_dotenv

load_dotenv()

# === LLM Setup ===
try:
    import ollama
    OLLAMA_AVAILABLE = True
except:
    OLLAMA_AVAILABLE = False

try:
    from groq import Groq
    GROQ_AVAILABLE = bool(os.getenv("GROQ_API_KEY"))
except:
    GROQ_AVAILABLE = False

try:
    import google.generativeai as genai
    if os.getenv("GEMINI_API_KEY"):
        genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
        GEMINI_AVAILABLE = True
    else:
        GEMINI_AVAILABLE = False
except:
    GEMINI_AVAILABLE = False

# === Board Configuration ===
BOARD_OPTIONS = [
    ("ESP32 DevKit", "esp32dev"),
    ("ESP32-CAM", "esp32cam"),
    ("ESP8266 NodeMCU", "nodemcuv2"),
    ("Arduino Uno R4 WiFi", "uno_r4_wifi"),
    ("Arduino Nano 33 IoT", "nano_33_iot"),
    ("Arduino Uno (classic)", "uno"),
    ("Arduino Nano (ATmega328)", "nanoatmega328"),
    ("Arduino Mega 2560", "megaatmega2560"),
    ("Raspberry Pi Pico W", "pico2"),
]

WIFI_BOARDS = {"esp32dev", "esp32cam", "nodemcuv2", "uno_r4_wifi", "nano_33_iot", "pico2"}
OTA_BOARDS = {"esp32dev", "esp32cam", "nodemcuv2", "uno_r4_wifi", "nano_33_iot"}

PLATFORM_MAP = {
    "esp32dev": "espressif32",
    "esp32cam": "espressif32",
    "nodemcuv2": "espressif8266",
    "uno_r4_wifi": "renesas_uno",
    "nano_33_iot": "atmelsam",
    "pico2": "raspberrypi",
    "uno": "atmelavr",
    "nanoatmega328": "atmelavr",
    "megaatmega2560": "atmelavr",
}

# === Paths ===
BASE_DIR = Path(__file__).parent
OUTPUT_DIR = BASE_DIR / "generated_projects"
OUTPUT_DIR.mkdir(exist_ok=True)

# === LLM Calls ===
def call_llm(provider: str, prompt: str) -> str:
    """Call LLM with error handling"""
    try:
        if provider == "ollama" and OLLAMA_AVAILABLE:
            response = ollama.chat(
                model="codestral",
                messages=[{"role": "user", "content": prompt}]
            )
            return response["message"]["content"]
        
        elif provider == "groq" and GROQ_AVAILABLE:
            client = Groq(api_key=os.getenv("GROQ_API_KEY"))
            response = client.chat.completions.create(
                messages=[{"role": "user", "content": prompt}],
                model="llama-3.3-70b-versatile",
                temperature=0.1,
                max_tokens=3000
            )
            return response.choices[0].message.content
        
        elif provider == "gemini" and GEMINI_AVAILABLE:
            model = genai.GenerativeModel("gemini-2.0-flash-exp")
            response = model.generate_content(prompt)
            return response.text
        
        return f"❌ {provider} not available"
    
    except Exception as e:
        return f"❌ LLM Error: {str(e)}"

# === Code Parsing ===
def extract_code_blocks(text: str, filename: str) -> str:
    """Extract code from markdown blocks or delimiters"""
    # Try markdown code blocks first
    pattern = rf"```(?:cpp|c\+\+)?\s*\n(.*?)```"
    matches = re.findall(pattern, text, re.DOTALL)
    if matches:
        return matches[0].strip()
    
    # Try custom delimiters
    pattern = rf"---\s*{re.escape(filename)}\s*---\s*(.*?)(?=---|$)"
    matches = re.findall(pattern, text, re.DOTALL | re.IGNORECASE)
    if matches:
        return matches[0].strip()
    
    # Fallback: return whole text if it looks like code
    if "#include" in text or "void setup" in text:
        return text.strip()
    
    return ""

# === Project Generation ===
def generate_project(
    mode: str,
    description: str,
    libraries: str,
    board_id: str,
    provider: str,
    ino_file,
    progress=gr.Progress()
):
    """Main generation function"""
    progress(0, desc="Initializing...")
    
    # Auto-enhance description if it's not already in clean English
    if mode == "description" and description.strip():
        progress(0.05, desc="Enhancing prompt...")
        enhanced_desc = enhance_prompt(description, provider)
        if not enhanced_desc.startswith("❌"):
            description = enhanced_desc
            progress(0.1, desc=f"Using: {description[:50]}...")
    
    # Create project structure
    project_name = "embedded_project"
    project_path = OUTPUT_DIR / project_name
    
    if project_path.exists():
        shutil.rmtree(project_path)
    
    project_path.mkdir(parents=True)
    src_dir = project_path / "src"
    src_dir.mkdir(exist_ok=True)
    
    # Determine input
    if mode == "refactor" and ino_file:
        progress(0.1, desc="Reading .ino file...")
        with open(ino_file.name, "r", encoding="utf-8") as f:
            ino_content = f.read()
        
        base_prompt = f"""Convert this Arduino .ino sketch to modular C++ for PlatformIO.
Board: {board_id}
Create separate files: main.cpp, sensors.h/cpp, network.h/cpp

Original code:
{ino_content}
"""
    else:
        progress(0.1, desc="Preparing prompt...")
        base_prompt = f"""Create modular C++ code for embedded project.
Board: {board_id}
Description: {description}
Libraries: {libraries}

Generate separate modules for sensors, networking, etc.
"""
    
    # Generate modules
    modules = []
    has_wifi = board_id in WIFI_BOARDS
    
    if has_wifi:
        modules.append("network")
    modules.append("sensors")
    
    lib_list = [lib.strip() for lib in libraries.split("\n") if lib.strip()]
    
    # Auto-add WiFi libraries for WiFi boards if not specified
    if has_wifi and not lib_list:
        if board_id in {"esp32dev", "esp32cam"}:
            lib_list.append("WiFi")
        elif board_id == "nodemcuv2":
            lib_list.append("ESP8266WiFi")
        elif board_id == "uno_r4_wifi":
            lib_list.append("WiFiS3")
        elif board_id == "nano_33_iot":
            lib_list.append("WiFiNINA")
        elif board_id == "pico2":
            lib_list.append("WiFi")
    
    progress(0.2, desc="Generating main.cpp...")
    
    # Generate main.cpp
    main_prompt = f"""{base_prompt}

Write ONLY main.cpp with setup() and loop() functions.
Include necessary headers. Format:

```cpp
// main.cpp code here
```
"""
    
    main_code = call_llm(provider, main_prompt)
    main_extracted = extract_code_blocks(main_code, "main.cpp")
    
    if main_extracted:
        (src_dir / "main.cpp").write_text(main_extracted, encoding="utf-8")
    else:
        # Fallback
        (src_dir / "main.cpp").write_text(
            "#include <Arduino.h>\n\nvoid setup() {\n  Serial.begin(115200);\n}\n\nvoid loop() {\n  delay(1000);\n}\n",
            encoding="utf-8"
        )
    
    # Generate modules
    for i, module in enumerate(modules):
        progress(0.3 + i * 0.3, desc=f"Generating {module}...")
        
        module_prompt = f"""{base_prompt}

Write {module}.h and {module}.cpp for the {module} module.
Format EXACTLY like this:

--- {module}.h ---
// header code
--- {module}.cpp ---
// implementation
"""
        
        module_code = call_llm(provider, module_prompt)
        
        # Parse header
        h_pattern = rf"---\s*{module}\.h\s*---\s*(.*?)(?=---|$)"
        h_match = re.search(h_pattern, module_code, re.DOTALL | re.IGNORECASE)
        
        if h_match:
            h_code = h_match.group(1).strip()
            h_code = extract_code_blocks(h_code, f"{module}.h") or h_code
            (src_dir / f"{module}.h").write_text(h_code, encoding="utf-8")
        
        # Parse cpp
        cpp_pattern = rf"---\s*{module}\.cpp\s*---\s*(.*?)$"
        cpp_match = re.search(cpp_pattern, module_code, re.DOTALL | re.IGNORECASE)
        
        if cpp_match:
            cpp_code = cpp_match.group(1).strip()
            cpp_code = extract_code_blocks(cpp_code, f"{module}.cpp") or cpp_code
            (src_dir / f"{module}.cpp").write_text(cpp_code, encoding="utf-8")
    
    progress(0.8, desc="Creating platformio.ini...")
    
    # Create platformio.ini
    platform = PLATFORM_MAP.get(board_id, "espressif32")
    
    # Build lib_deps section
    if lib_list:
        lib_deps = "\n".join(f"    {lib}" for lib in lib_list)
        lib_section = f"lib_deps =\n{lib_deps}"
    else:
        lib_section = "; lib_deps = (add libraries here if needed)"
    
    ini_content = f"""[env:{board_id}]
platform = {platform}
board = {board_id}
framework = arduino
{lib_section}
monitor_speed = 115200
"""
    
    (project_path / "platformio.ini").write_text(ini_content, encoding="utf-8")
    
    progress(0.9, desc="Creating README...")
    
    # Create README
    libs_section = "\n".join(f"- {lib}" for lib in lib_list) if lib_list else "*Auto-detected from code*"
    
    readme = f"""# {project_name.title()}

## Hardware
- Board: {board_id}
- Platform: {platform}

## Description
{description if mode == "description" else "Refactored from .ino sketch"}

## Libraries
{libs_section}

## Build
```bash
pio run
```

## Upload
```bash
pio run --target upload
```

## Monitor
```bash
pio device monitor
```

## License
MIT
"""
    
    (project_path / "README.md").write_text(readme, encoding="utf-8")
    
    progress(0.95, desc="Creating ZIP...")
    
    # Create ZIP
    zip_path = OUTPUT_DIR / f"{project_name}.zip"
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        for file in project_path.rglob('*'):
            if file.is_file():
                zf.write(file, file.relative_to(OUTPUT_DIR))
    
    progress(1.0, desc="✅ Complete!")
    
    return str(zip_path), f"✅ Project generated successfully!\n\nFiles created:\n- main.cpp\n- {', '.join(f'{m}.h/{m}.cpp' for m in modules)}\n- platformio.ini\n- README.md"

# === Compile Function ===
def compile_project():
    """Compile with PlatformIO"""
    project_path = OUTPUT_DIR / "embedded_project"
    
    if not project_path.exists():
        return "❌ No project generated yet. Click 'Generate' first."
    
    try:
        result = subprocess.run(
            ["pio", "run", "-d", str(project_path)],
            capture_output=True,
            text=True,
            timeout=120
        )
        
        output = result.stdout + result.stderr
        
        if result.returncode == 0:
            return f"✅ Compilation successful!\n\n{output}"
        else:
            return f"❌ Compilation failed:\n\n{output}"
    
    except FileNotFoundError:
        return "❌ PlatformIO not found.\n\nInstall: pip install -U platformio"
    
    except subprocess.TimeoutExpired:
        return "❌ Compilation timeout (>2min)"
    
    except Exception as e:
        return f"❌ Error: {str(e)}"

# === Custom CSS ===
custom_css = """
.gradio-container {
    max-width: 1200px !important;
}

/* Soft neutral theme */
.dark {
    --body-background-fill: #1a1a1a !important;
    --background-fill-primary: #262626 !important;
    --background-fill-secondary: #333333 !important;
    --border-color-primary: #404040 !important;
}

/* Accent color: warm orange instead of blue */
.primary {
    background: linear-gradient(135deg, #ff6b35 0%, #f7931e 100%) !important;
}

button.primary {
    background: linear-gradient(135deg, #ff6b35 0%, #f7931e 100%) !important;
    border: none !important;
}

button.primary:hover {
    background: linear-gradient(135deg, #ff8555 0%, #ffa43e 100%) !important;
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(255, 107, 53, 0.3);
}

/* Tab styling */
.tab-nav button {
    border-radius: 8px 8px 0 0;
    font-weight: 500;
}

.tab-nav button.selected {
    background: linear-gradient(135deg, #ff6b35 0%, #f7931e 100%) !important;
    color: white !important;
}

/* Input styling */
.textbox, .dropdown {
    border-radius: 8px;
}

/* Card effect for sections */
.form {
    background: var(--background-fill-secondary);
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}
"""

# === Prompt Enhancement ===
def enhance_prompt(raw_input: str, provider: str) -> str:
    """Improve and translate user input to clean English prompt"""
    if not raw_input.strip():
        return "❌ Please enter a description first"
    
    enhancement_prompt = f"""You are a technical writing assistant. Convert this user input into a clear, professional English prompt for embedded systems code generation.

Rules:
- Translate to English if needed
- Fix grammar and spelling
- Make it technical and specific
- Keep it concise (max 3 sentences)
- Focus on functionality, not implementation details

User input: {raw_input}

Output ONLY the improved prompt, nothing else."""

    result = call_llm(provider, enhancement_prompt)
    
    # Clean up common LLM artifacts
    result = result.strip()
    result = result.replace('"', '').replace("'", "")
    if result.startswith("Here") or result.startswith("Improved"):
        lines = result.split("\n")
        result = lines[-1] if lines else result
    
    return result.strip()

# === UI ===
with gr.Blocks(title="ESP32 Code Generator") as demo:
    gr.Markdown("""
    # 🔧 Embedded Project Generator
    **Local, AI-powered code generator for ESP32 and microcontrollers**
    
    Generate modular PlatformIO projects from natural language descriptions or refactor existing .ino files.
    Supports 10+ boards with automatic library detection, OTA for WiFi boards, and instant compilation feedback.
    """)
    
    # Mode Selection
    mode = gr.Radio(
        choices=[("📝 From Description", "description"), ("📄 Refactor .ino", "refactor")],
        value="description",
        label="Generation Mode",
        info="Choose how to create your project"
    )
    
    # Input containers (conditional visibility)
    with gr.Group(visible=True) as desc_inputs:
        description = gr.Textbox(
            label="Project Description (any language - will be auto-enhanced)",
            placeholder="z.B.: ich brauch sensor für temperatur und webseite...\nExample: need temperature sensor with web display...",
            lines=3
        )
        libraries = gr.Textbox(
            label="Libraries (one per line, optional)",
            placeholder="Leave empty for auto-detection or specify:\nDHT sensor library\nAdafruit NeoPixel\nServo",
            lines=4,
            value=""
        )
    
    with gr.Group(visible=False) as ino_inputs:
        ino_file = gr.File(
            label="Upload .ino File",
            file_types=[".ino"],
            type="filepath"
        )
        gr.Markdown("*Libraries will be auto-detected from #include statements*")
    
    # Common inputs
    with gr.Row():
        board = gr.Dropdown(
            choices=BOARD_OPTIONS,
            value="esp32dev",
            label="Target Board",
            info="Select your microcontroller"
        )
        
        provider_choices = []
        if OLLAMA_AVAILABLE:
            provider_choices.append(("🏠 Ollama (Local)", "ollama"))
        if GROQ_AVAILABLE:
            provider_choices.append(("☁️ Groq (Cloud)", "groq"))
        if GEMINI_AVAILABLE:
            provider_choices.append(("🤖 Gemini (Google)", "gemini"))
        
        if not provider_choices:
            provider_choices = [("⚠️ No LLM Available", "none")]
        
        provider = gr.Radio(
            choices=provider_choices,
            value=provider_choices[0][1] if provider_choices else "none",
            label="AI Backend"
        )
    
    # Action buttons
    with gr.Row():
        btn_generate = gr.Button("🚀 Generate Project", variant="primary", scale=2)
        btn_compile = gr.Button("⚙️ Compile", scale=1)
    
    # Outputs
    output_zip = gr.File(label="📦 Download Project", interactive=False)
    output_log = gr.Textbox(
        label="Output Log",
        lines=10,
        interactive=False
    )
    
    # === Event Handlers ===
    
    def toggle_inputs(mode_val):
        """Toggle input visibility based on mode"""
        if mode_val == "description":
            return gr.update(visible=True), gr.update(visible=False)
        else:
            return gr.update(visible=False), gr.update(visible=True)
    
    mode.change(
        toggle_inputs,
        inputs=[mode],
        outputs=[desc_inputs, ino_inputs]
    )
    
    btn_generate.click(
        generate_project,
        inputs=[mode, description, libraries, board, provider, ino_file],
        outputs=[output_zip, output_log]
    )
    
    btn_compile.click(
        compile_project,
        outputs=[output_log]
    )
    
    # Footer
    gr.Markdown("""
    ---
    **Tips:**
    - Use descriptive project descriptions for better code generation
    - Include all necessary libraries
    - Check the generated code before uploading to hardware
    """)

if __name__ == "__main__":
    demo.launch(
        server_name="127.0.0.1",
        server_port=7860,
        css=custom_css,
        theme=gr.themes.Soft()
    )
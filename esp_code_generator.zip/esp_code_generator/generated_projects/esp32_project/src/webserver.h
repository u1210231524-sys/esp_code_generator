```cpp
#ifndef WEBSERVER_H
#define WEBSERVER_H

#include <WiFi.h>
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include "DHT.h"
#include <ArduinoOTA.h>

class WebServer {
public:
    WebServer(int dhtPin, int type);
    void begin();
private:
    AsyncWebServer server;
    DHT dht;
    float tempCelsius;
    float tempFahrenheit;
};

#endif // WEBSERVER_H
```
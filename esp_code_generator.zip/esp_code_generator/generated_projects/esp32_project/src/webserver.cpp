```cpp
#include "webserver.h"

WebServer::WebServer(int dhtPin, int type) : dht(dhtPin, type), server(80){}

void WebServer::begin() {
    // Initialize DHT sensor
    dht.begin();

    // Initialize OTA
    ArduinoOTA.setHostname("ESP32WebServer");
    ArduinoOTA.begin();

    server.on("/", HTTP_GET, [this](AsyncWebServerRequest *request){
        tempCelsius = dht.readTemperature();
        tempFahrenheit = dht.readTemperature(true);

        String html = "<html><body>";
        html += "Temperature: ";
        html += tempCelsius;
        html += "°C / ";
        html += tempFahrenheit;
        html += "°F";
        html += "</body></html>";

        request->send(200, "text/html", html);
    });

    server.begin();
}
```
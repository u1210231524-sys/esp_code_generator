```cpp
#include "sensors.h"

Sensors::Sensors(uint8_t pin) {
    dht = new DHT(pin, DHT22);
}

void Sensors::begin() {
    dht->begin();
}

float Sensors::readTemperature() {
    return dht->readTemperature();
}

float Sensors::readHumidity() {
    return dht->readHumidity();
}
```
In the above code, `sensors.h` contains the header for the sensor class and `sensors.cpp` contains the implementation of that class. The class `Sensors` is responsible for initializing the DHT22 sensor on a given pin, reading temperature and humidity values from it. This design makes the code modular and reusable.
```cpp
#ifndef SENSORS_H
#define SENSORS_H

#include <DHT.h>

class Sensors {
public:
    Sensors(uint8_t pin);
    void begin();
    float readTemperature();
    float readHumidity();
private:
    DHT *dht;
};

#endif // SENSORS_H
```
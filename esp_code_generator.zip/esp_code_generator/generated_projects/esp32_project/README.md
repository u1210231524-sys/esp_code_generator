 # ESP32 Web Server with DHT22 and OTA

This project is a simple yet powerful web server application running on an ESP32 development board, featuring integration with a DHT22 temperature/humidity sensor and Over-The-Air (OTA) updates for easy firmware upgrades.

## Features

- **DHT22 Sensor**: The web server fetches real-time data from the DHT22 sensor, displaying current temperature and humidity on a user-friendly interface.
- **Web Server**: Serves static HTML files, providing an interactive UI for users to view sensor data in real-time or trigger OTA updates.
- **Over-The-Air (OTA) Updates**: Allows firmware updates directly through the web server, eliminating the need for manual flashing or reprogramming of the ESP32 board.

## Prerequisites

Before you begin, ensure that you have the following prerequisites:

- An ESP32 development board (esp32dev) with the appropriate firmware installed.
- A DHT22 temperature/humidity sensor connected to the ESP32 board.
- Basic knowledge of Arduino programming and web development.

## Installation

1. Clone this repository to your local machine or download the source code as a ZIP file.
2. Open the project in your preferred Arduino IDE (Integrated Development Environment).
3. Install any necessary libraries listed in the `libraries` directory using the Arduino Library Manager.
4. Configure the project settings to match your hardware setup and preferences, such as sensor pin assignments and Wi-Fi credentials.
5. Upload the code to your ESP32 development board.
6. Access the web server through your preferred web browser by navigating to `http://[your_esp32_ip]`.

## Usage

Once the project is installed and running, you can:

- View real-time temperature and humidity data on the web interface.
- Trigger Over-The-Air (OTA) updates by navigating to `http://[your_esp32_ip]/update` and uploading a new firmware file using the provided form.

## Troubleshooting

If you encounter any issues during installation or usage, please refer to the following troubleshooting tips:

- Ensure that all hardware connections are secure and correct.
- Double-check your Wi-Fi credentials in the `config.h` file.
- Verify that the web server is running on the expected IP address.
- If OTA updates fail, make sure you upload a valid firmware file with the appropriate size and format.

## Contributing

Contributions to this project are welcome! If you have any improvements or bug fixes, please submit a pull request. For major changes, please open an issue first to discuss your ideas.

## License

This project is licensed under the [MIT License](LICENSE).
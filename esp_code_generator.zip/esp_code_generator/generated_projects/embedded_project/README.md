# Embedded_Project

## Hardware
- Board: esp32dev
- Platform: espressif32

## Description
Refactored from .ino sketch

## Libraries
- WiFi

## Build
```bash
pio run
```

## Upload
```bash
pio run --target upload
```

## Monitor
```bash
pio device monitor
```

## License
MIT

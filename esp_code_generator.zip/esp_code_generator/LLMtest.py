# app.py
import os
import gradio as gr
from pathlib import Path
import shutil
import zipfile
import traceback
from dotenv import load_dotenv

load_dotenv()

# === LLM-Backends laden ===
try:
    import ollama
    OLLAMA_AVAILABLE = True
except Exception:
    OLLAMA_AVAILABLE = False

try:
    from groq import Groq
    GROQ_AVAILABLE = bool(os.getenv("GROQ_API_KEY"))
except Exception:
    GROQ_AVAILABLE = False

try:
    import google.generativeai as genai
    if os.getenv("GEMINI_API_KEY"):
        genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
        GEMINI_AVAILABLE = True
    else:
        GEMINI_AVAILABLE = False
except Exception:
    GEMINI_AVAILABLE = False

# === Hauptfunktion: LLM aufrufen mit DETAIILLIERTEN Fehlern ===
def call_llm(model_provider: str, prompt: str) -> str:
    try:
        if model_provider == "ollama" and OLLAMA_AVAILABLE:
            response = ollama.chat(model="codestral", messages=[{"role": "user", "content": prompt}])
            return response["message"]["content"]
        
        elif model_provider == "groq" and GROQ_AVAILABLE:
            client = Groq(api_key=os.getenv("GROQ_API_KEY"))
            response = client.chat.completions.create(
                messages=[{"role": "user", "content": prompt}],
                model="llama-3.3-70b-versatile",  # ✅ Korrekt gemäß Deprecation (6. Jan 2025)
                temperature=0.1,
                max_tokens=2000
            )
            return response.choices[0].message.content
        
        elif model_provider == "gemini" and GEMINI_AVAILABLE:
            model = genai.GenerativeModel("gemini-2.0-flash")  # ✅ Verfügbar laut deinem Modell-List
            response = model.generate_content(
                prompt,
                safety_settings={
                    "HARM_CATEGORY_DANGEROUS_CONTENT": "BLOCK_NONE",
                    "HARM_CATEGORY_HARASSMENT": "BLOCK_NONE",
                    "HARM_CATEGORY_SEXUALLY_EXPLICIT": "BLOCK_NONE",
                    "HARM_CATEGORY_HATE_SPEECH": "BLOCK_NONE"
                }
            )
            return response.text
        
        else:
            return f"❌ Backend '{model_provider}' ist nicht verfügbar.\n- Ollama: {'OK' if OLLAMA_AVAILABLE else 'Nicht gefunden'}\n- Groq: {'OK' if GROQ_AVAILABLE else 'Kein API-Key in .env'}\n- Gemini: {'OK' if GEMINI_AVAILABLE else 'Kein gültiger API-Key'}"

    except Exception as e:
        # 🔥 Zeigt DEN GENAUEN FEHLER + VOLLSTÄNDIGEN TRACEBACK
        error_detail = traceback.format_exc()
        return f"❌ FEHLER MIT {model_provider.upper()}:\n{str(e)}\n\n--- VOLLER FEHLER ---\n{error_detail}"

# === Einfache Testfunktion ===
def test_llm(provider: str):
    return call_llm(provider, "Schreibe 'Hallo Welt' auf Englisch.")

# === WebUI ===
with gr.Blocks(title="ESP32 Code Generator – Fehlerdiagnose") as demo:
    gr.Markdown("## 🔍 LLM-Backend Test – Fehler werden vollständig angezeigt")
    
    provider = gr.Radio(
        choices=[
            ("Ollama (local)", "ollama"),
            ("Groq (cloud)", "groq"),
            ("Gemini (Google)", "gemini")
        ],
        value="ollama",
        label="Wähle LLM-Backend"
    )
    
    btn = gr.Button("🔍 Teste Verbindung")
    output = gr.Textbox(label="Ergebnis oder Fehlermeldung", lines=15)

    btn.click(test_llm, inputs=provider, outputs=output)

demo.launch(server_name="127.0.0.1", server_port=7860)